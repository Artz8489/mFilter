import React, { Component } from 'react'

export default class DemoEdit extends Component {
    render() {
        return (
            <div>Demo Edit</div>
        )
    }
}
