import React, { Component } from 'react'

export default class mtrackitDashboard extends Component {
    render() {
        return (
            <div>Demo View</div>
        )
    }
}
