const EndPoints = {
  download: `/api/bi/report/download`,
};
const ApiUrl = 'https://infringementapi.mfilterit.net';

export { EndPoints, ApiUrl };
