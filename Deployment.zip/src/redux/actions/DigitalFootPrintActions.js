import * as constant from '../constants/DigitalFootPrintConstants';
export const GetDigitalFootPrint = () => {
  return {
    type: constant.DIGITALFOOTPRINT_INIT,
  };
};
