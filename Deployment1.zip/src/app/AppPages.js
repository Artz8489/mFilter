import React, { useEffect, Suspense, lazy } from 'react';
import { Redirect, Switch, Route, useLocation } from 'react-router-dom';
import { LayoutSplashScreen, ContentRoute } from '../_metronic/layout';
import PageLoader from './PageLoader';
import { useSelector, useDispatch, connect } from 'react-redux';
import {
  setLocalStorage,
  getLocalStorage,
  removeLocalStorage,
} from "../app/utils/helpers"

// App pages
const ThreeSixtyDegree = lazy(() => import('./views/app/360-degree'));
const Dashboard = lazy(() => import('./views/app/dashboard'));
// const AuthPage = lazy(() => import("./modules/Auth/pages/AuthPage"));

const DemoPages = lazy(() => import('./views/app/demo'));
const Issues = lazy(() => import('./views/app/issues'));
const Packages = lazy(() => import('./views/app/packages'));
const Reports = lazy(() => import('./views/app/reports'));
const TicketingSystem = lazy(() => import('./views/app/ticketing-system'));
const Tickets = lazy(() => import('./views/app/tickets'));
const Users = lazy(() => import('./views/app/users'));
const DigitalFootPrint = lazy(() => import('./views/app/digitalfootprint'));
const ChangePassword = lazy(() => import('./views/app/changepassword'));
const ErrorPage = lazy(() => import('./views/app/errors'));
const PackageUser = lazy(() => import('./views/app/packageuser'));
const UserManagement = lazy(() => import('./views/app/usermanagement'));
const Verifications = lazy(() => import('./views/app/verifications'));
const DeepDiveAnalysis = lazy(() => import('./views/app/deepDive'));

 

export  function AppPages({menuLists}) {
  const isAuthorized = JSON.parse(localStorage.getItem('auth_data'));
  const pathName = useLocation().pathname
  const menuList = JSON.parse(
    getLocalStorage('MENU_LIST_VALUE')
  );
  const getMenuRoute = (arr) => {
    const tempRoute = []
      arr && arr.length > 0 && arr.map(menu => {
        if (menu.route) {
          tempRoute.push(menu.route)
        }
      })
    return tempRoute
  }


const checkVaild = (path) => {
  let valid = false
  if (getMenuRoute(menuList).includes(path)) {
    valid = true
  }
  return valid
}



  return (
    <Suspense fallback={<PageLoader />}>      
      <Switch>
        {/* {
                    <Redirect exact from="/" to="/incident-dashboard" />
                } */}
        {/* <ContentRoute path="/" component={Dashboard} /> */}


       
        <ContentRoute
          path='/incident-dashboard'
          render={(props) => isAuthorized && checkVaild(pathName)
            ? <Dashboard {...props} />
            : <Redirect to='/incident-dashboard' />}
        />

        <ContentRoute
          path='/degree-search'
          render={(props) => isAuthorized && checkVaild(pathName)
            ? <ThreeSixtyDegree {...props} />
            : <Redirect to='/incident-dashboard' />}
        />

        <ContentRoute
          path='/demo'
          render={(props) => isAuthorized
            ? <DemoPages {...props} />
            : <Redirect to='/incident-dashboard' />}
        />

        <ContentRoute
          path='/verification'
          render={(props) => isAuthorized && checkVaild(pathName)
            ? <Verifications {...props} />
            : <Redirect to='/incident-dashboard' />}
        />
        <ContentRoute
          // path='/verifications/address' 
          path='/address_check' 
          render={(props) => isAuthorized && checkVaild(pathName)
            ? <Verifications {...props} />
            : <Redirect to='/incident-dashboard' />}
        />

        <ContentRoute
          path='/issue'
          render={(props) => isAuthorized && checkVaild(pathName)
            ? <Issues {...props} />
            : <Redirect to='/incident-dashboard' />}
        />

        <ContentRoute
          path='/packages'
          render={(props) => isAuthorized && checkVaild(pathName)
            ? <Packages {...props} />
            : <Redirect to='/incident-dashboard' />}
        />

        <ContentRoute
          path='/deepdive'
          render={(props) => isAuthorized && checkVaild(pathName)
            ? <DeepDiveAnalysis {...props} />
            : <Redirect to='/incident-dashboard' />}
        />

        <ContentRoute
          path='/report'
          render={(props) => isAuthorized && checkVaild(pathName)
            ? <Reports {...props} />
            : <Redirect to='/incident-dashboard' />}
        />

        <ContentRoute
          path='/ticketing-system'
          render={(props) => isAuthorized && checkVaild(pathName)
            ? <TicketingSystem {...props} />
            : <Redirect to='/incident-dashboard' />}
        />

        <ContentRoute
          path='/issues'
          render={(props) => isAuthorized && checkVaild(pathName)
            ? <Tickets {...props} />
            : <Redirect to='/incident-dashboard' />}
        />


        <ContentRoute
          path='/user'
          render={(props) => isAuthorized && checkVaild(pathName)
            ? <Users {...props} />
            : <Redirect to='/incident-dashboard' />}
        />
        <ContentRoute
          path='/verification' 
          render={(props) => isAuthorized && checkVaild(pathName)
            ? <Users {...props} />
            : <Redirect to='/incident-dashboard' />}
        />

        <ContentRoute
          path='/digital_foot_prints'
          render={(props) => isAuthorized && checkVaild(pathName)
            ? <DigitalFootPrint {...props} />
            : <Redirect to='/incident-dashboard' />}
        />

        <ContentRoute
          path='/changepassword'
          render={(props) => isAuthorized 
            ? <ChangePassword {...props} />
            : <Redirect to='/incident-dashboard' />}
        />

        <ContentRoute
          path='/package-user'
          render={(props) => isAuthorized && checkVaild(pathName)
            ? <PackageUser {...props} />
            : <Redirect to='/incident-dashboard' />}
        />

        <ContentRoute
          path='/usermanagement'
          render={(props) => isAuthorized && checkVaild(pathName)
            ? <UserManagement {...props} />
            : <Redirect to='/incident-dashboard' />}
        />
       
       


      </Switch>
    </Suspense>
  );
}

const mapStateToProps = (state) => {
  const { common } = state
  return {
    menuLists: common && common?.menu_list ? common.menu_list?.menus : [],
  }
}
export default connect(mapStateToProps)(AppPages) 
