import React, { lazy, Suspense } from "react";
import { Switch, Route, Redirect } from "react-router-dom";

const Mtrackit = ({ match }) => (
    <Suspense>
        <Switch>
            {<Redirect exact={true} from="/mtrackit" to="/mtrackit/dashboard"/>}
            <Route path={`${match.url}/dashboard`} component={lazy(() => import(`./mtrackitDashboard`))} />
        </Switch>
    </Suspense>
);

export default Mtrackit;