import React, { useEffect } from 'react';
 
const Errors=()=> {

    return (
        <h1>
            Errors....!
        </h1>
    );
}
 
export default Errors;