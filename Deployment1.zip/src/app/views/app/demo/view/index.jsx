import React, { Component } from 'react'

export default class DemoView extends Component {
    render() {
        return (
            <div>Demo View</div>
        )
    }
}
