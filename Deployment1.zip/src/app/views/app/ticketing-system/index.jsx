import React from 'react';

const TicketingSystem = () => {

    return (
        <h1>
            TicketingSystem....!
        </h1>
    );
}

export default TicketingSystem;