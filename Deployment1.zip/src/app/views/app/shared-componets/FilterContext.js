import React from 'react'

function FilterContext() {
  return (
    <div>FilterContext</div>
  )
}

export default FilterContext

