import * as constant from '../constants/DeepDiveConstants';

export const FetchDeepDiveURL = () => {
  return {
    type: constant.DEEPDIVE_INIT,
  };
};
