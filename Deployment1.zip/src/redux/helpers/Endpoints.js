const getauthvalue = JSON.parse(localStorage.getItem('auth_data'));



const id = getauthvalue && getauthvalue?.id;
const project_id = getauthvalue && getauthvalue?.redmine?.project_id ? getauthvalue?.redmine?.project_id : '';

// https://infringementapi.mfilterit.net/api/ticket/

const EndPoints = {
  counts_data: `/api/bi/plots/counts`,
  package_name: `/api/user/${id}/package`,
  menu_list: `/api/user/${id}/menu`,
  filter_list: `/api/user/${id}/filter`,
  incident_volume: `/api/bi/plots/incident_volume`,
  activecases_channel: `/api/bi/plots/active_cases_by_channel`,
  sub_channel: `/api/bi/plots/sub_channel`,
  topten_location: `/api/bi/plots/top_ten_location`,
  category_level_count: `/api/bi/plots/category_level_count`,
  publisher_level_count: `/api/bi/plots/publisher_level_count`,
  channel_list: `/api/bi/filters/channel`,
  country_list: `/api/bi/filters/country`,
  category_list: `/api/bi/filters/category`,
  brand_list: `/api/bi/filters/brand`,
  priority_list: `/api/bi/filters/priority`,
  publisher_list: `/api/bi/filters/publisher`,
  status_list: `/api/bi/filters/status`,
  report_list: `/api/bi/report`,
  create_ticket: `/api/bi/ticket/${id}/`,
  create_multiple_ticket: `/api/bi/report/bulk_ticket/${id}`,
  ticket_detail: `/api/ticket/single/`,
  ticket_customer: `/api/bi/ticket-customer/${id}`,
  priority: `/api/bi/ticket-priority`,
  // fetch ticket page
  // https://infringementapi.mfilterit.net/api/ticket/all/ckxpydjs50004icfaf0v97io7?limit=100&offset=0
  ticket: `/api/ticket/all/${id}/`,
  // ticket: `/api/ticket/${project_id}`,
  search_ticket: `/api/ticket/single`,
  download_report: `/api/bi/report/download`,
  status_ticket: `/api/bi/ticket-status`,
  ticket_update: `/api/ticket/${id}`,
  login: `/api/user/login`,
  change: `/api/user/change_password`,
  close_ticket: `/api/bi/report/bulk_ticket/${id}`,
  save_ticket: `/api/bi/report/update_priority_and_status_bulk/${id}`,
  THREESIXTY_UPLOAD: `/api/bi/${id}/360`,
  DIGITAL_FOOT_PRINT: '/api/digitalfootprint',
  DEEP_DIVE_ANALYSIS:
    `/api/user/${id}/deepdive?package_name=in.amazonlpt`,
  VERIFICATION_URL:
    `https://merchantonboarding.mfilterit.net/api/v1/master?api_key=awsd2d_fefqw2dw`,
  BULK_BANK_VERIFICATION_URL:
    `https://merchantonboarding.mfilterit.net/api/v1/bulk_process`,
  THREESIXTY_GET_TICKET: `/api/bi/ckxpydjs50004icfaf0v97io7/360`,
}


const ApiUrl = "https://devwebfraud.mfilterit.net"
// const ApiUrl = "https://infringementapi.mfilterit.net"

export { EndPoints, ApiUrl }