import { takeLatest, put, call } from "redux-saga/effects";
import * as constant from "../constants/LoginConstants";
import LoginServices from "../services/LoginServices";

export function* ViewLoginIncidentsSaga(payload) {
    try {
        const response = yield call(LoginServices.ViewLoginincidents ,payload.logindata);
        yield put({ type: constant.LOGIN_INCIDENTS_SUCCESS,response })
    } catch (error) {
        yield put({ type: constant.LOGIN_INCIDENTS_ERROR,error })
    }
}

export function* ViewChangeIncidentsSaga(payload){
    try {
        const response = yield call(LoginServices.ViewChangeincidents ,payload.changedata);
        yield put({ type: constant.CHANGE_INCIDENTS_SUCCESS,response })
    } catch (error) {
        yield put({ type: constant.CHANGE_INCIDENTS_ERROR,error })
    }
}

export default function* LoginSaga() {
    yield takeLatest(constant.LOGIN_INCIDENTS, ViewLoginIncidentsSaga);
    yield takeLatest(constant.CHANGE_INCIDENTS, ViewChangeIncidentsSaga);
}
