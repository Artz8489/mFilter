import { takeLatest, put, call } from 'redux-saga/effects';
import * as constant from '../constants/DigitalFootPrintConstants';
import DigitalFootPrintService from '../services/DigitalFootPrintService';

export function* viewDigitalFootPrintSaga(payload) {
  console.log('payload in saga report ', payload);
  try {
    const response = yield call(DigitalFootPrintService.getReport);
    console.log('response', response);
    yield put({ type: constant.DIGITALFOOTPRINT_SUCCESS, response });
  } catch (error) {
    yield put({ type: constant.DIGITALFOOTPRINT_ERROR, error });
  }
}
export default function* DigitalFootPrintSaga() {
  yield takeLatest(constant.DIGITALFOOTPRINT_INIT, viewDigitalFootPrintSaga);
}
