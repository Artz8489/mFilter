import { takeLatest, put, call } from "redux-saga/effects";
import * as constant from "../constants/DownloadConstants";
import DownloadService from "../services/DownloadService";

export function* DownloadReportSaga(payload) {
    try {
        const response = yield call(DownloadService.DownloadReportlist, payload.downloaddata);
        yield put({ type: constant.DOWNLOAD_INIT_SUCCESS, response })
    } catch (error) {
        yield put({ type: constant.DOWNLOAD_INIT_ERROR, error })
    }
}

export default function* DownloadSaga() {
    yield takeLatest(constant.DOWNLOAD_INIT, DownloadReportSaga);


}