import { EndPoints, ApiUrl } from '../helpers/Endpoints';
import axios from 'axios'
const DownloadServices = {}
DownloadServices.DownloadReportlist = function (queryParams) {
    let searchParams = new URLSearchParams()
    Object.keys(queryParams).forEach(key => searchParams.append(key, queryParams[key]));
    let url = ApiUrl + EndPoints.download_report + "?" + searchParams
    return fetch(url,{
        method: "GET",
        headers: {
              'Content-Type': 'text/csv',
        'Accept': 'application/json'
        
    }
      })
        .then(async response => {
            const data =  await response.text();
            return data;
            if (!response.ok) {
                const error = (data && data.message) || response.statusText;
                return Promise.reject(error);
            }
        })
        .catch(error => {
            console.error('There was an error!', error);
        });
}

export default DownloadServices