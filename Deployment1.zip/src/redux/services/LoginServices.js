import { EndPoints, ApiUrl } from '../helpers/Endpoints';

const LoginServices = {}



LoginServices.ViewLoginincidents = function async(body) {
    const requestOptions = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
    }
    let url = ApiUrl + EndPoints.login

    return fetch(url, requestOptions)
        .then(async response => {
            const data = await response.json()
            return data

            if (!response.ok) {
                const error = (data && data.message) || response.status;
                return Promise.reject(error);
            }

        })
        .catch(error => {
            console.error('There was an error!', error);
        });



}

LoginServices.ViewChangeincidents = function async(body) {
    const requestOptions = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
    }
    let url = ApiUrl + EndPoints.change

    return fetch(url, requestOptions)
    .then(async response => {
        const data = await response.json()
        // if(requestOptions.data.status === 200){
        //     console.log("success")
        // }else {
        //     console.log("error")
        // }
        return data;
        console.log("dataaaaa",data.message);
        

       

        // if (!response.ok) {
        //     const error = (data && data.message) || response.status;
        //     return Promise.reject(error);
        // }

    })
    .catch(error => {
        console.error('There was an error!', error);
    });


}

export default LoginServices
