import React, { useMemo, useEffect } from "react";
import objectPath from "object-path";
import { useLocation } from "react-router";
import SVG from "react-inlinesvg";
import { OverlayTrigger, Tooltip } from "react-bootstrap";
import { toAbsoluteUrl } from "../../../_helpers";
import { useHtmlClassService } from "../../_core/MetronicLayout";
import { SearchDropdown } from "../extras/dropdowns/search/SearchDropdown";
import { UserNotificationsDropdown } from "../extras/dropdowns/UserNotificationsDropdown";
import { QuickActionsDropdown } from "../extras/dropdowns/QuickActionsDropdown";
import { MyCartDropdown } from "../extras/dropdowns/MyCartDropdown";
import { LanguageSelectorDropdown } from "../extras/dropdowns/LanguageSelectorDropdown";
import * as constant from "../../../../redux/constants/DashboardConstants";
import { useDispatch } from "react-redux";
import { QuickUserToggler } from "../extras/QuiclUserToggler";
import {
  getBreadcrumbsAndTitle,
  useSubheader,
} from "../../_core/MetronicSubheader";
import { PictureAsPdfSharp } from "@material-ui/icons";
// import {getBreadcrumbsAndTitle, useSubheader} from "../../_core/MetronicSubheader";

export function Topbar() {
  const dispatch = useDispatch();
  const uiService = useHtmlClassService();
  const subheader = useSubheader();
  const location = useLocation();
  const layoutProps = useMemo(() => {
    return {
      viewSearchDisplay: objectPath.get(
        uiService.config,
        "extras.search.display"
      ),
      viewNotificationsDisplay: objectPath.get(
        uiService.config,
        "extras.notifications.display"
      ),
      viewQuickActionsDisplay: objectPath.get(
        uiService.config,
        "extras.quick-actions.display"
      ),
      viewCartDisplay: objectPath.get(uiService.config, "extras.cart.display"),
      viewQuickPanelDisplay: objectPath.get(
        uiService.config,
        "extras.quick-panel.display"
      ),
      viewLanguagesDisplay: objectPath.get(
        uiService.config,
        "extras.languages.display"
      ),
      viewUserDisplay: objectPath.get(uiService.config, "extras.user.display"),
      asideSelfMinimizeToggle: objectPath.get(
        uiService.config,
        "aside.self.minimize.toggle"
      ),
    };
  }, [uiService]);

  useEffect(() => {
    if (location.pathname === "/incident-dashboard") {
      subheader.setTitle("Dashboard");
    }
    if (location.pathname === "/report") {
      subheader.setTitle("Report");
    }
    if (location.pathname === "/issues") {
      subheader.setTitle("Tickets");
    }
  }, []);

  return (
    <div className="col-lg-12">
      <div className="topbar">
        <div className="col-lg-6">
          <div className="d-flex justify-content-start flex-start">
            <h5 className="text-dark font-weight-bold my-7 mr-5">
              <>{subheader.title}</>
            </h5>
          </div>
        </div>
        <div className="col-lg-6">
          <div className="d-flex justify-content-end flex-end my-3">
            {layoutProps.viewQuickPanelDisplay &&
              ((location.pathname === "/incident-dashboard") ||
              (location.pathname === "/report") ? (
              // ((subheader && subheader.title == "Dashboard") ||
              // (subheader && subheader.title == "Report") ? (
                <OverlayTrigger
                  placement="bottom"
                  overlay={<Tooltip id="quick-panel-tooltip">Filter</Tooltip>}
                >
                  <div
                    className="topbar-item"
                    data-toggle="tooltip"
                    title="Filter"
                    data-placement="right"
                  >
                    {layoutProps.asideSelfMinimizeToggle && (
                      <div
                        className="btn btn-icon btn-clean btn-lg mr-1"
                        // id="kt_quick_panel_toggle"
                        // id="kt_aside_toggle"
                      >
                        {/* onClick={()=> {console.log('onclickToogle')}}              */}

                        <button
                          className="brand-toggle btn btn-sm px-0"
                          onClick={() => {
                            dispatch({
                              type: constant.SET_SIDE_DRAWER,
                              setSideDrawer: true,
                            });
                          }}
                        >
                          <span className="svg-icon svg-icon-xl svg-icon-primary">
                            <SVG
                              pointer-events="none"
                              src={toAbsoluteUrl(
                                "media/svg/icons/Text/Filter.svg"
                              )}
                            />
                          </span>
                        </button>
                      </div>
                    )}
                  </div>
                </OverlayTrigger>
              ) : (
                ""
              ))}

            {layoutProps.viewUserDisplay && <QuickUserToggler />}
          </div>
        </div>
      </div>
    </div>
  );
}
