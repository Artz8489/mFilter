import React, { useMemo, useState, useEffect } from "react";
import { AsideMenuList } from "./AsideMenuList";
import { useHtmlClassService } from "../../../_core/MetronicLayout";
import Select from 'react-select'
import { FetchPackagename, FetchMenulist } from "../../../../../redux/actions/CommonActions";
import {
  FetchTotalIncidents, FetchIncidentVolumes, FetchActivecasesbychannel, FetchSubchannel,
  FetchToptenLocation, FetchCategorlevelcount, FetchPublisherlevelcount
}
  from "../../../../../redux/actions/DashboardActions";
  import {
    FetchReport
   
  } from "../../../../../redux/actions/ReportActions";
  import {
    setLocalStorage,
    getLocalStorage,
    removeLocalStorage,
  } from "../../../../../../src/app/utils/helpers";
import { useSelector, useDispatch } from 'react-redux';
import { connect } from 'react-redux'
import * as constant from "../../../../../redux/constants/CommonConstants";
import { SET_PACKAGE_CHANGE } from "../../../../../redux/constants/DashboardConstants";
import {
  FILTER_CATEGORY_SELECTED_VALUE
} from "../../../../../../src/app/utils/const";

export function AsideMenu({ disableScroll }) {
  const package_name = useSelector(state => state.common.package_name)

  const [defValue, setDefValue]= useState(null)
  const [packages, setPackges]= useState(null)
  //let packages = null;
  localStorage.setItem("dpackage", defValue?.value);
  const [dpackage, setPackage] = useState(localStorage.getItem('dpackage'));
  
  const uiService = useHtmlClassService();
  const dispatch = useDispatch();
  const layoutProps = useMemo(() => {
    return {
      layoutConfig: uiService.config,
      asideMenuAttr: uiService.getAttributes("aside_menu"),
      ulClasses: uiService.getClasses("aside_menu_nav", true),
      asideClassesFromConfig: uiService.getClasses("aside_menu", true)
    };
  }, [uiService]);

  const getLocalPackname = localStorage.getItem("selectedPackage");

  const handleOnchange = (e) => {
    setDefValue(e)
    localStorage.setItem("dpackage", e.value);
    localStorage.setItem("selectedPackage", JSON.stringify(e));
    setPackage(e.value);
    dispatch({ type: constant.SET_GLOBAL_PACKAGE_NAME, setGlobalPackageName: e.value })
    const data = {
      "package_name": e.value,
      "fromDate": localStorage.getItem("startDate"),
      "toDate": localStorage.getItem("endDate"),
      "country": "all",
      "category": "all",
      "publisher": "all",
      "channel": "all",
      "brand": "all",
      "status": "all",
      "priority": "all"
    }
    dispatch(FetchMenulist(e.value))
    dispatch(FetchTotalIncidents(data))
    dispatch(FetchIncidentVolumes(data))
    dispatch(FetchActivecasesbychannel(data))
    dispatch(FetchSubchannel(data))
    dispatch(FetchToptenLocation(data))
    dispatch(FetchCategorlevelcount(data))
    dispatch(FetchPublisherlevelcount(data))
    dispatch(FetchReport(data))
    removeLocalStorage(FILTER_CATEGORY_SELECTED_VALUE.SELECTED)
  }

  useEffect(() => {
    dispatch(FetchPackagename())
  }, [])


  
  useEffect(() => {
    if(package_name && package_name.length > 0){
      let tempPack=[]
      package_name.map((pack, i) => (
          tempPack.push({ value: pack.package_name, label: pack.package_name })
      ))
      setPackges(tempPack)
      // setDefValue(tempPack[0])
      if (getLocalPackname) {
        setDefValue(JSON.parse(getLocalPackname))
      } else {
        setDefValue(tempPack[0])
      }
    }
  }, [package_name])

  return (
    <>
      <div
        id="kt_aside_menu"
        data-menu-vertical="1"
        className={`aside-menu ${layoutProps.asideClassesFromConfig}`}
        {...layoutProps.asideMenuAttr}>

        
          <li style={{listStyle:"none"}}className="pr-5 pl-5">
            <Select
              value={defValue}
              onChange={handleOnchange}
              options={packages}
            />
          </li>
        
    

        <AsideMenuList layoutProps={layoutProps} />
      </div>
    </>
  );
}

const mapStateToProps = (state) => {
  const { common } = state;
}
export default connect(mapStateToProps)(AsideMenu) 


